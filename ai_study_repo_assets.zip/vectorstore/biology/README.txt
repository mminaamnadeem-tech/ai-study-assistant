Place this subject's generated index.faiss and metadata.json here.
